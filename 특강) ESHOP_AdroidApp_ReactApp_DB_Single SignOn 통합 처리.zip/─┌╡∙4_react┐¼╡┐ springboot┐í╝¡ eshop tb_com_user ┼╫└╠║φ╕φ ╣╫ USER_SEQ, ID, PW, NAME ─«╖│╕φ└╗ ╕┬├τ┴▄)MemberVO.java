package com.springboot.login.user.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;


@SequenceGenerator(
		name = "MEMBER_IDX_SEQ_GEN",
		sequenceName = "USER_SEQ",
		initialValue = 1,
		allocationSize = 1		
		)
@Data
@Entity
@Table(name = "TB_COM_USER")
public class MemberVO {

	@Id
	@GeneratedValue(
			strategy = GenerationType.SEQUENCE,
			generator = "MEMBER_IDX_SEQ_GEN"
			)
//	@Column(name = "MEMBER_IDX")
//	private int memberIdx;
	@Column(name = "ID")
	private String memberId;
	@Column(name = "PW")
	private String memberPw;
	@Column(name = "NAME")
	private String memberName;	
}
